# My First Nextjs Project

After learning something about nextjs i started building my own website. 

My project is a blog website in  the project i am implementing what i have learned about nextjs.

lets start from the first step 

##how to create a nextjs project

To start a nextjs project i am using VScode. In the vscode, i opened the terminal and write 

npx create-next-app@latest with the reference from the nextjs docs. 

i am using the app route in my project. 

in the project i have added very limited pages:

 

A home page where all the blogs are there.

I added the read more link, and after clicking it it opeans the detailed blog.

I added the images that display in the homepage.

in the detailed blog page there is a link the navigates back to the  home page.

i have also learned many ways to render the blog data onto the website.  By using the internal data ( by adding the blog data in the data folder and render it) or external data or fetching the mdx files using rss or APIs. 

Right now i am learning about the React Hooks and components.